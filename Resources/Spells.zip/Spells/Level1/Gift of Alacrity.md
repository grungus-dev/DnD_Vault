Source: Explorer's Guide to Wildemount

*1st-level divination (dunamancy:chronurgy)*

**Casting Time:** 1 minute  
**Range:** Touch  
**Components:** V, S  
**Duration:** 8 hours

You touch a willing creature. For the duration, the target can add 1d8 to its initiative rolls.

***Spell Lists.*** [Wizard (Dunamancy)](Wizard)