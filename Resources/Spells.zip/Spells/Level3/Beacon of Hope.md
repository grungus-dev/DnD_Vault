Source: Player's Handbook

*3rd-level abjuration*

**Casting Time:** 1 action  
**Range:** 30 feet  
**Components:** V, S  
**Duration:** Concentration, up to 1 minute

This spell bestows hope and vitality. Choose any number of creatures within range. For the duration, each target has advantage on Wisdom saving throws and death saving throws, and regains the maximum number of hit points possible from any healing.

***Spell Lists.*** [Cleric](Cleric)