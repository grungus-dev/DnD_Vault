Source: Strixhaven: A Curriculum of Chaos

*2nd-level Divination*

**Casting Time:** 1 action  
**Range:** Self  
**Components:** V, S, M (a book worth at least 25 gp)  
**Duration:** 1 hour

You draw on knowledge from spirits of the past. Choose one skill in which you lack proficiency. For the spell's duration, you have proficiency in the chosen skill. The spell ends early if you cast it again.

***Spell Lists.*** [Bard](Bard), [Cleric](Cleric), [Warlock](Warlock), [Wizard](Wizard)