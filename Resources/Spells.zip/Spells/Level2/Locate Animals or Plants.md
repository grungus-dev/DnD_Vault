Source: Player's Handbook

*2nd-level divination (ritual)*

**Casting Time:** 1 action  
**Range:** Self  
**Components:** V, S, M (a bit of fur from a bloodhound)  
**Duration:** Instantaneous

Describe or name a specific kind of beast or plant. Concentrating on the voice of nature in your surroundings, you learn the direction and distance to the closest creature or plant of that kind within 5 miles, if any are present.

***Spell Lists.*** [Bard](Bard), [Druid](Druid), [Ranger](Ranger)