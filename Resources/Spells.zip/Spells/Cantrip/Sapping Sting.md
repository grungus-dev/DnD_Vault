Source: Explorer's Guide to Wildemount

*Necromancy cantrip*

**Casting Time:** 1 action  
**Range:** 30 feet  
**Components:** V, S  
**Duration:** Instantaneous

You sap the vitality of one creature you can see in range. The target must succeed on a Constitution saving throw or take 1d4 necrotic damage and fall prone.

***At Higher Levels.*** This spell's damage increases by 1d4 when you reach 5th level (2d4), 11th level (3d4), and 17th level (4d4).

***Spell Lists.*** [Wizard (Dunamancy)](Wizard)