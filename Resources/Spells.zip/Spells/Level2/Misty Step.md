Source: Player's Handbook

*2nd-level conjuration*

**Casting Time:** 1 bonus action  
**Range:** Self  
**Components:** V  
**Duration:** Instantaneous

Briefly surrounded by silvery mist, you teleport up to 30 feet to an unoccupied space that you can see.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)