Source: Player's Handbook

*2nd-level divination (ritual)*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** S  
**Duration:** Concentration, up to 1 hour

You touch a willing beast. For the duration of the spell, you can use your action to see through the beast's eyes and hear what it hears, and continue to do so until you use your action to return to your normal senses.

***Spell Lists.*** [Druid](Druid), [Ranger](Ranger)