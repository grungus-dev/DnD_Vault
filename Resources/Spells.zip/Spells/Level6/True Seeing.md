Source: Player's Handbook

*6th-level divination*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (an ointment for the eyes that costs 25 gp; is made from mushroom powder, saffron, and fat; and is consumed by the spell)  
**Duration:** 1 hour

This spell gives the willing creature you touch the ability to see things as they actually are. For the duration, the creature has truesight, notices secret doors hidden by magic, and can see into the Ethereal Plane, all out to a range of 120 feet.

***Spell Lists.*** [Bard](Bard), [Cleric](Cleric), [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)