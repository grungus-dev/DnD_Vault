Source: Player's Handbook

*1st-level necromancy*

**Casting Time:** 1 action  
**Range:** Self  
**Components:** V, S, M (a small amount of alcohol or distilled spirits)  
**Duration:** 1 hour

Bolstering yourself with a necromantic facsimile of life, you gain 1d4 + 4 temporary hit points for the duration.

***At Higher Levels.*** When you cast this spell using a spell slot of 2nd level or higher, you gain 5 additional temporary hit points for each slot level above 1st.

***Spell Lists.*** [Artificer](Artificer), [Sorcerer](Sorcerer), [Wizard](Wizard)