Source: Player's Handbook

*2nd-level divination*

**Casting Time:** 1 action  
**Range:** Self  
**Components:** V, S, M (a pinch of talc and a small sprinkling of powdered silver)  
**Duration:** 1 hour

For the duration, you see invisible creatures and objects as if they were visible, and you can see into the Ethereal Plane. Ethereal creatures and objects appear ghostly and translucent.

***Spell Lists.*** [Artificer](Artificer), [Bard](Bard), [Sorcerer](Sorcerer), [Wizard](Wizard)