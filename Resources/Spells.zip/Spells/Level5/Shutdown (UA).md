Source: Unearthed Arcana 7 - Modern Magic

*5th-level transmutation (technomagic)*

**Casting Time:** 1 action  
**Range:** 120 feet  
**Components:** V, S  
**Duration:** Concentration, up to 1 minute

This spell shuts down all electronic devices within range that are not wielded by or under the direct control of a creature. If an electronic device within range is used by a creature, that creature must succeed on a Constitution saving throw to prevent the device from being shut down. While the spell remains active, no electronic device within range can be started or restarted.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)