Source: Player's Handbook

*3rd-level evocation*

**Casting Time:** 1 action  
**Range:** Self  
**Components:** V  
**Duration:** Concentration, up to 1 minute

Holy power radiates from you in an aura with a 30-foot radius, awakening boldness in friendly creatures. Until the spell ends, the aura moves with you, centered on you. While in the aura, each non-hostile creature in the aura (including you) deals an extra 1d4 radiant damage when it hits with a weapon attack.

***Spell Lists.*** [Paladin](Paladin)