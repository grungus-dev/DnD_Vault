Source: Unearthed Arcana 85 - Wonders of the Multiverse

*3rd-level enchantment*

**Casting Time:** 1 action  
**Range:** 30 feet  
**Components:** V, S, M (a playing card depicting a rogue)  
**Duration:** Instantaneous

You whisper magical words that antagonize one creature of your choice within range. The target must make a Wisdom saving throw. On a failed save, it takes 4d4 psychic damage and must immediately use its reaction, if available, to make a melee attack against another creature of your choice that you can see. If no other creature is within range, the target has disadvantage on the next attack roll it makes before the start of your next turn.

***At Higher Levels.*** When you cast this spell using a spell slot of 4th level or higher, the damage increases by 1d4 for each slot level above 3rd.

***Spell Lists.*** [Bard](Bard), [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)