Source: Player's Handbook

*Abjuration cantrip*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (a miniature cloak)  
**Duration:** Concentration, up to 1 minute

You touch one willing creature. Once before the spell ends, the target can roll a d4 and add the number rolled to one saving throw of its choice. It can roll the die before or after the saving throw. The spell then ends.

***Spell Lists.*** [Artificer](Artificer), [Cleric](Cleric), [Druid](Druid)