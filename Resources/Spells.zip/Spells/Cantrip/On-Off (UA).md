Source: Unearthed Arcana 7 - Modern Magic

*Transmutation cantrip (technomagic)*

**Casting Time:** 1 action  
**Range:** 60 feet  
**Components:** V, S  
**Duration:** Instantaneous

This cantrip allows you to activate or deactivate any electronic device within range, as long as the device has a clearly defined on or off function that can be easily accessed from the outside of the device. Any device that requires a software-based shutdown sequence to activate or deactivate cannot be affected by On/Off.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)