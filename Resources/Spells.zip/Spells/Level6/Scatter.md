Source: Xanathar's Guide to Everything

*6th-level conjuration*

**Casting Time:** 1 action  
**Range:** 30 feet  
**Components:** V  
**Duration:** Instantaneous

The air quivers around up to five creatures of your choice that you can see within range. An unwilling creature must succeed on a Wisdom saving throw to resist this spell. You teleport each affected target to an unoccupied space that you can see within 120 feet of you. That space must be on the ground or on a floor.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)