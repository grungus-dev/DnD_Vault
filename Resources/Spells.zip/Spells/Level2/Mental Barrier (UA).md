Source: Unearthed Arcana 66 - Fighter, Rogue, and Wizard

*2nd-level abjuration*

**Casting Time:** 1 reaction, which you take when you are forced to make an Intelligence, a Wisdom, or a Charisma saving throw  
**Range:** Self  
**Components:** V  
**Duration:** 1 round

You protect your mind with a wall of looping, repetitive thought. Until the start of your next turn, you have advantage on Intelligence, Wisdom, and Charisma saving throws, and you have resistance to psychic damage.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)