Source: Player's Handbook

*4th-level evocation*

**Casting Time:** 1 bonus action  
**Range:** Self  
**Components:** V  
**Duration:** Concentration, up to 1 minute

The next time you hit a creature with a melee weapon attack during this spell's duration, your weapon pierces both body and mind, and the attack deals an extra 4d6 psychic damage to the target. The target must make a Wisdom saving throw. On a failed save, it has disadvantage on attack rolls and ability checks, and can't take reactions, until the end of its next turn.

***Spell Lists.*** [Paladin](Paladin)