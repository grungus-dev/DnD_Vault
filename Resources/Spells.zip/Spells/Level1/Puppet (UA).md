Source: Unearthed Arcana 36 - Starter Spells

*1st-level enchantment*

**Casting Time:** 1 action  
**Range:** 120 feet  
**Components:** V  
**Duration:** Instantaneous

Your gesture forces one humanoid you can see within range to make a Constitution saving throw. On a failed save, the target must move up to its speed in a direction you choose. In addition, you can cause the target to drop whatever it is holding. This spell has no effect on a humanoid that is immune to being charmed.

***Spell Lists.*** [Bard](Bard), [Warlock](Warlock), [Wizard](Wizard)


***HB note:***
This spell is somewhat overpowered. Forced movement is one thing, but forced disarmament is very strong. I would recommend allowing only forced movement or forced disarmament, not both.