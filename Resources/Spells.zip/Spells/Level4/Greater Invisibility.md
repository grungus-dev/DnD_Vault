Source: Player's Handbook

*4th-level illusion*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S  
**Duration:** Concentration, up to 1 minute

You or a creature you touch becomes invisible until the spell ends. Anything the target is wearing or carrying is invisible as long as it is on the target's person.

***Spell Lists.*** [Bard](Bard), [Sorcerer](Sorcerer), [Wizard](Wizard)