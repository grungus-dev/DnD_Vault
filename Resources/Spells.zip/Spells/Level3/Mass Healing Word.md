Source: Player's Handbook

*3rd-level evocation*

**Casting Time:** 1 bonus action  
**Range:** 60 feet  
**Components:** V  
**Duration:** Instantaneous

As you call out words of restoration, up to six creatures of your choice that you can see within range regain hit points equal to 1d4 + your spellcasting ability modifier. This spell has no effect on undead or constructs.

***At Higher Levels.*** When you cast this spell using a spell slot of 4th level or higher, the healing increases by 1d4 for each slot level above 3rd.

***Spell Lists.*** [Bard (Optional)](Bard), [Cleric](Cleric)