Source: Player's Handbook

*1st-level abjuration*

**Casting Time:** 1 bonus action  
**Range:** 60 feet  
**Components:** V, S, M (a small parchment with a bit of holy text written on it)  
**Duration:** Concentration, up to 10 minutes

A shimmering field appears and surrounds a creature of your choice within range, granting it a +2 bonus to AC for the duration.

***Spell Lists.*** [Cleric](Cleric), [Paladin](Paladin)