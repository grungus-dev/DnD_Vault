Source: Unearthed Arcana 66 - Fighter, Rogue, and Wizard

*4th-level enchantment*

**Casting Time:** 1 action  
**Range:** 30 feet  
**Components:** V  
**Duration:** Concentration, up to 1 minute

You lash the mind of one creature you can see within range, filling it with despair. The target must succeed on an Intelligence saving throw or suffer disadvantage on attack rolls, ability checks, and saving throws, and it can't cast spells. At the end of each of its turns, the target can make another Intelligence saving throw. On a success, the spell ends on the target.

***Spell Lists.*** [Bard](Bard), [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)