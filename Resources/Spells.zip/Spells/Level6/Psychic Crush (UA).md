Source: Unearthed Arcana 66 - Fighter, Rogue, and Wizard

*6th-level enchantment*

**Casting Time:** 1 action  
**Range:** 60 feet  
**Components:** V, S  
**Duration:** 1 minute

You overload the mind of one creature you can see within range, filling its psyche with discordant emotions. The target must make an Intelligence saving throw. On a failed save, the target takes 12d6 psychic damage and is stunned for 1 minute. On a successful save, the target takes half as much damage and isn't stunned.

The stunned target can make an Intelligence saving throw at the end of each of its turns. On a successful save, the spell ends on the target.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)