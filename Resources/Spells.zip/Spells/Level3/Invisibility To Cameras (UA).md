Source: Unearthed Arcana 7 - Modern Magic

*3rd-level illusion (technomagic)*

**Casting Time:** 1 action  
**Range:** 10 feet  
**Components:** V, S, M (a scrap of black paper)  
**Duration:** Concentration, up to 1 minute

Four creatures of your choice within range become undetectable to electronic sensors and cameras for the duration of the spell. Anything a target is wearing or carrying is likewise undetectable as long as it is on the target's person. The targets remain visible to vision.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)