Source: Player's Handbook

*3rd-level necromancy*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (diamonds worth 300 gp, which the spell consumes)  
**Duration:** Instantaneous

You touch a creature that has died within the last minute. That creature returns to life with 1 hit point. This spell can't return to life a creature that has died of old age, nor can it restore any missing body parts.

***Spell Lists.*** [Artificer](Artificer), [Cleric](Cleric), [Druid (Optional)](Druid), [Paladin](Paladin), [Ranger (Optional)](Ranger)