Source: Player's Handbook

*Necromancy cantrip*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S  
**Duration:** Instantaneous

You touch a living creature that has 0 hit points. The creature becomes stable. This spell has no effect on undead or constructs.

***Spell Lists.*** [Artificer](Artificer), [Cleric](Cleric)