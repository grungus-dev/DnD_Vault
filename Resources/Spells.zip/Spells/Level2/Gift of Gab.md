Source: Acquisitions Inc.

*2nd-level enchantment*

**Casting Time:** 1 reaction, which you take when you speak to another creature  
**Range:** Self  
**Components:** V, S, M (2 gold coins, which is consumed as tax for using the spell)  
**Duration:** Instantaneous

When you cast this spell, you skillfully reshape the memories of listeners in your immediate area, so that each creature of your choice within 5 feet of you forgets everything you said within the last 6 seconds. Those creatures then remember that you actually said the words you speak as the verbal component of the spell.

***Spell Lists.*** [Bard](Bard), [Wizard](Wizard)