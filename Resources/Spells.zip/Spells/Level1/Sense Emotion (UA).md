Source: Unearthed Arcana 36 - Starter Spells

*1st-level divination*

**Casting Time:** 1 action  
**Range:** Self  
**Components:** V, S  
**Duration:** Concentration, up to 1 minute

You attune your senses to pick up the emotions of others for the duration. When you cast the spell, and as your action on each turn until the spell ends, you can focus your senses on one humanoid you can see within 30 feet of you. You instantly learn the target's prevailing emotion, whether it's love, anger, pain, fear, calm, or something else. If the target isn't actually humanoid or it is immune to being charmed, you sense that it is calm.

***Spell Lists.*** [Bard](Bard), [Warlock](Warlock), [Wizard](Wizard)