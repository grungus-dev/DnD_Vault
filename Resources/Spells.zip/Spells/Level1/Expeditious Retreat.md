Source: Player's Handbook

*1st-level transmutation*

**Casting Time:** 1 bonus action  
**Range:** Self  
**Components:** V, S  
**Duration:** Concentration, up to 10 minutes

This spell allows you to move at an incredible pace. When you cast this spell, and then as a bonus action on each of your turns until the spell ends, you can take the Dash action.

***Spell Lists.*** [Artificer](Artificer), [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)