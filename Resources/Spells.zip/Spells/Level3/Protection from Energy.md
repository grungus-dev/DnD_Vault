Source: Player's Handbook

*3rd-level abjuration*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S  
**Duration:** Concentration, up to 1 hour

For the duration, the willing creature you touch has resistance to one damage type of your choice: acid, cold, fire, lightning, or thunder.

***Spell Lists.*** [Artificer](Artificer), [Cleric](Cleric), [Druid](Druid), [Ranger](Ranger), [Sorcerer](Sorcerer), [Wizard](Wizard)