Source: Player's Handbook

*1st-level transmutation*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (a grasshopper's hind leg)  
**Duration:** 1 minute

You touch a creature. The creature's jump distance is tripled until the spell ends.

***Spell Lists.*** [Artificer](Artificer), [Druid](Druid), [Ranger](Ranger), [Sorcerer](Sorcerer), [Wizard](Wizard)