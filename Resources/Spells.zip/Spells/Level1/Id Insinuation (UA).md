Source: Unearthed Arcana 66 - Fighter, Rogue, and Wizard

*1st-level enchantment*

**Casting Time:** 1 action  
**Range:** 60 feet  
**Components:** V, S  
**Duration:** Concentration, up to 1 minute

You unleash a torrent of conflicting desires in the mind of one creature you can see within range, impairing its ability to make decisions. The target must succeed on a Wisdom saving throw or be incapacitated. At the end of each of its turns, it takes 1d12 psychic damage, and it can then make another Wisdom saving throw. On a success, the spell ends on the target.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)