Source: Player's Handbook

*Divination cantrip*

**Casting Time:** 1 action  
**Range:** 30 feet  
**Components:** S  
**Duration:** Concentration, up to 1 round

You extend your hand and point a finger at a target in range. Your magic grants you a brief insight into the target's defenses. On your next turn, you gain advantage on your first attack roll against the target, provided that this spell hasn't ended.

***Spell Lists.*** [Bard](Bard), [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)