Source: Xanathar's Guide to Everything

*Evocation cantrip*

**Casting Time:** 1 action  
**Range:** 5 feet  
**Components:** V, M (a holy symbol)  
**Duration:** Instantaneous

You utter a divine word, and burning radiance erupts from you. Each creature of your choice that you can see within range must succeed on a Constitution saving throw or take 1d6 radiant damage.

***At Higher Levels.*** The spell's damage increases by 1d6 when you reach 5th level (2d6), 11th level (3d6), and 17th level (4d6).

***Spell Lists.*** [Cleric](Cleric)