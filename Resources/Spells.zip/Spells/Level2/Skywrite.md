Source: Xanathar's Guide to Everything

*2nd-level transmutation (ritual)*

**Casting Time:** 1 action  
**Range:** Sight  
**Components:** V, S  
**Duration:** Concentration, up to 1 day

You cause up to ten words to form in a part of the sky you can see. The words appear to be made of cloud and remain in place for the spell's duration. The words dissipate when the spell ends. A strong wind can disperse the clouds and end the spell early.

***Spell Lists.*** [Bard](Bard), [Druid](Druid), [Wizard](Wizard), [Artificer](Artificer)