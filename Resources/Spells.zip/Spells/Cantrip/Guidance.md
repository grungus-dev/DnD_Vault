Source: Player's Handbook

*Divination cantrip*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S  
**Duration:** Concentration, up to 1 minute

You touch one willing creature. Once before the spell ends, the target can roll a d4 and add the number rolled to one ability check of its choice. It can roll the die before or after making the ability check. The spell then ends.

***Spell Lists.*** [Artificer](Artificer), [Cleric](Cleric), [Druid](Druid)