Source: Xanathar's Guide to Everything

*5th-level conjuration*

**Casting Time:** 1 bonus action  
**Range:** Self  
**Components:** V  
**Duration:** Concentration, up to 1 minute

You teleport up to 60 feet to an unoccupied space you can see. On each of your turns before the spell ends, you can use a bonus action to teleport in this way again.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)