Source: Player's Handbook

*Abjuration cantrip*

**Casting Time:** 1 action  
**Range:** Self  
**Components:** V, S  
**Duration:** 1 round

You extend your hand and trace a sigil of warding in the air. Until the end of your next turn, you have resistance against bludgeoning, piercing, and slashing damage dealt by weapon attacks.

***Spell Lists.*** [Bard](Bard), [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)