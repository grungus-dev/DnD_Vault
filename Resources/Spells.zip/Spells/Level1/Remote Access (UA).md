Source: Unearthed Arcana 7 - Modern Magic

*1st-level transmutation (technomagic)*

**Casting Time:** 1 action  
**Range:** 120 feet  
**Components:** V, S  
**Duration:** 10 minutes

You can use any electronic device within range as if it were in your hands. This is not a telekinesis effect. Rather, this spell allows you to simulate a device's mechanical functions electronically. You are able to access only functions that a person using the device manually would be able to access. You can use remote access with only one device at a time.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)