Source: Player's Handbook

*1st-level evocation*

**Casting Time:** 1 bonus action  
**Range:** Self  
**Components:** V  
**Duration:** Concentration, up to 1 minute

The first time you hit with a melee weapon attack during this spell's duration, your weapon rings with thunder that is audible within 300 feet of you, and the attack deals an extra 2d6 thunder damage to the target. Additionally, if the target is a creature, it must succeed on a Strength saving throw or be pushed 10 feet away from you and knocked prone.

***Spell Lists.*** [Paladin](Paladin)