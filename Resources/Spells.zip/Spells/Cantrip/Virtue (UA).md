Source: Unearthed Arcana 36 - Starter Spells

*Abjuration cantrip*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S  
**Duration:** 1 round

You touch one creature, imbuing it with vitality. If the target has at least 1 hit point, it gains a number of temporary hit points equal to 1d4 + your spellcasting ability modifier. The temporary hit points are lost when the spell ends.

***Spell Lists.*** [Cleric](Cleric)