Source: Player's Handbook

*1st-level transmutation*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (a pinch of dirt)  
**Duration:** 1 hour

You touch a creature. The target's speed increases by 10 feet until the spell ends.

***At Higher Levels.*** When you cast this spell using a spell slot of 2nd level or higher, you can target one additional creature for each slot level above 1st.

***Spell Lists.*** [Artificer](Artificer), [Bard](Bard), [Druid](Druid), [Ranger](Ranger), [Wizard](Wizard)