Source: Player's Handbook

*1st-level enchantment*

**Casting Time:** 1 action  
**Range:** 30 feet  
**Components:** V, S, M (a morsel of food)  
**Duration:** 24 hours

This spell lets you convince a beast that you mean it no harm. Choose a beast that you can see within range. It must see and hear you. If the beast's Intelligence is 4 or higher, the spell fails. Otherwise, the beast must succeed on a Wisdom saving throw or be charmed by you for the spell's duration. If you or one of your companions harms the target, the spell ends.

***At Higher Levels.*** When you cast this spell using a spell slot of 2nd level or higher, you can affect one additional beast for each slot level above 1st.

***Spell Lists.*** [Bard](Bard), [Druid](Druid), [Ranger](Ranger)