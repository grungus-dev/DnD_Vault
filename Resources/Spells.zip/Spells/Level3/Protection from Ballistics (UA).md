Source: Unearthed Arcana 7 - Modern Magic

*3rd-level abjuration (technomagic)*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (a shell casing)  
**Duration:** Concentration, up to 10 minutes

This spell enchants the flesh of the target against the impact of bullets. Until the spell ends, the target has resistance to nonmagical ballistic damage.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)