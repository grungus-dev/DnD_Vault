Source: Critical Role ([Twitter](Twitter))

*Necromancy cantrip*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S  
**Duration:** 1 minute

You reach out and touch the corpse of a creature. Over the next minute, the corpse begins to rapidly decompose, sprouting fungus and moss as it begins to degrade into compost and mulch. An odd-colored flower or two may also spring from the corpse in this time. Applicable requirements for resurrection are unaffected by this decomposition.

***Spell Lists.*** [Cleric](Cleric)