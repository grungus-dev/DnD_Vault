Source: Acquisitions Inc.

*2nd-level enchantment*

**Casting Time:** 1 action  
**Range:** 60 feet  
**Components:** S, M (a coin, 2 gold coins, which is consumed as tax for using the spell)  
**Duration:** 1 minute

When you cast the spell, you hurl the coin that is the spell's material component to any spot within range. The coin lights up as if under the effect of a light spell. Each creature of your choice that you can see within 30 feet of the coin must succeed on a Wisdom saving throw or be distracted for the duration. While distracted, a creature has disadvantage on Wisdom (Perception) checks and initiative rolls.

***Spell Lists.*** [Wizard](Wizard)