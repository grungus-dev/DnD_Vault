Source: Xanathar's Guide to Everything

*6th-level abjuration*

**Casting Time:** 1 action  
**Range:** Self  
**Components:** V, S  
**Duration:** Concentration, up to 1 minute

You have resistance to acid, cold, fire, lightning, and thunder damage for the spell's duration.

When you take damage of one of those types, you can use your reaction to gain immunity to that type of damage, including against the triggering damage. If you do so, the resistances end, and you have the immunity until the end of your next turn, at which time the spell ends.

***Spell Lists.*** [Druid](Druid)