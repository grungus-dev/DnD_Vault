Source: Player's Handbook

*1st-level abjuration*

**Casting Time:** 1 reaction, which you take when you are hit by an attack or targeted by the *[magic missile](magic missile)* spell  
**Range:** Self  
**Components:** V, S  
**Duration:** 1 round

An invisible barrier of magical force appears and protects you. Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from *[magic missile](magic missile)*.

***Spell Lists.*** [Sorcerer](Sorcerer), [Wizard](Wizard)