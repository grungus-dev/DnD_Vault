Source: Unearthed Arcana 66 - Fighter, Rogue, and Wizard

*2nd-level abjuration*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S  
**Duration:** 8 hours

You weave a clouding veil over the mind of one creature you touch. For the duration, the target's mind can't be read or detected, creatures can't telepathically communicate with the target unless the target allows it, and the target has advantage on saving throws against any effect that would determine whether it is telling the truth.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)