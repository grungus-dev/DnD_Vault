Source: Player's Handbook

*3rd-level transmutation (ritual)*

**Casting Time:** 1 action  
**Range:** 30 feet  
**Components:** V, S, M (a short reed or piece of straw)  
**Duration:** 24 hours

This spell grants up to ten willing creatures you can see within range the ability to breathe underwater until the spell ends. Affected creatures also retain their normal mode of respiration.

***Spell Lists.*** [Artificer](Artificer), [Druid](Druid), [Ranger](Ranger), [Sorcerer](Sorcerer), [Wizard](Wizard)