Source: Player's Handbook

*1st-level necromancy*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S  
**Duration:** Instantaneous

Make a melee spell attack against a creature you can reach. On a hit, the target takes 3d10 necrotic damage.

***At Higher Levels.*** When you cast this spell using a spell slot of 2nd level or higher, the damage increases by 1d10 for each slot level above 1st.

***Spell Lists.*** [Cleric](Cleric)