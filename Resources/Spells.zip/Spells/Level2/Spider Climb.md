Source: Player's Handbook

*2nd-level transmutation*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (a drop of bitumen and a spider)  
**Duration:** Concentration, up to 1 hour

Until the spell ends, one willing creature you touch gains the ability to move up, down, and across vertical surfaces and upside down along ceilings, while leaving its hands free. The target also gains a climbing speed equal to its walking speed.

***Spell Lists.*** [Artificer](Artificer), [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)