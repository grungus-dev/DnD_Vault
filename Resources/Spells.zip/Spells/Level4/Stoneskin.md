Source: Player's Handbook

*4th-level abjuration*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (diamond dust worth 100 gp, which the spell consumes)  
**Duration:** Concentration, up to 1 hour

This spell turns the flesh of a willing creature you touch as hard as stone. Until the spell ends, the target has resistance to nonmagical bludgeoning, piercing, and slashing damage.

***Spell Lists.*** [Artificer](Artificer), [Druid](Druid), [Ranger](Ranger), [Sorcerer](Sorcerer), [Wizard](Wizard)