Source: Unearthed Arcana 7 - Modern Magic

*2nd-level abjuration (technomagic)*

**Casting Time:** 1 action  
**Range:** Self  
**Components:** V, S, M (a small piece of copper wire)  
**Duration:** Concentration, up to 1 hour

This spell works to actively hide your presence within a computer system. For the spell's duration, you and any other users you choose on your local network gain a +10 bonus to Intelligence checks to avoid detection by administrators, knowbots, tracking software, and the like. Whenever you and your chosen users leave any computer system you are working in while this spell is in effect, all trace of your previous presence in that system is erased.

***Spell Lists.*** [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)