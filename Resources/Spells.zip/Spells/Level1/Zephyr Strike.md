Source: Xanathar's Guide to Everything

*1st-level transmutation*

**Casting Time:** 1 bonus action  
**Range:** Self  
**Components:** V  
**Duration:** Concentration, up to 1 minute

You move like the wind. For the duration, your movement doesn't provoke opportunity attacks.

Once before the spell ends, you can give yourself advantage on one weapon attack roll on your turn. That attack deals an extra 1d8 force damage on a hit. Whether you hit or miss, your walking speed increases by 30 feet until the end of that turn.

***Spell Lists.*** [Ranger](Ranger)