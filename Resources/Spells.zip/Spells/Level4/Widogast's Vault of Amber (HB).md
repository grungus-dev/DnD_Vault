Source: Critical Role ([Twitter](Twitter))

*4th-level transmutation (ritual)*

**Casting Time:** 1 minute  
**Range:** Touch  
**Components:** V, S, M (5 small amber gems worth 200 gp)  
**Duration:** Until dispelled

You arrange 5 small amber gems in a loose circle around any non-living materials and trace Transmutative sigils above each of them. All materials within the circle are pulled into the largest of the gems and are stored there, in stasis. The contents do not age, weather, or rot. The gem can hold up to 500lbs of material.

The caster can use an Action to speak a single, chosen word and release the gem's contents onto the ground. Contents are also released if dispelled.

***Spell Lists.*** [Wizard](Wizard)