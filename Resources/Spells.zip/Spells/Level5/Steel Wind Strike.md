Source: Xanathar's Guide to Everything

*5th-level conjuration*

**Casting Time:** 1 action  
**Range:** 30 feet  
**Components:** S, M (a melee weapon worth at least 1 sp)  
**Duration:** Instantaneous

You flourish the weapon used in the casting and then vanish to strike like the wind. Choose up to five creatures you can see within range. Make a melee spell attack against each target. On a hit, a target takes 6d10 force damage.

You can then teleport to an unoccupied space you can see within 5 feet of one of the targets you hit or missed.

***Spell Lists.*** [Ranger](Ranger), [Wizard](Wizard)