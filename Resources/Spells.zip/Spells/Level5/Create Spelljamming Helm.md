Source: Spelljammer: Adventures in Space - Astral Adventurer's Guide

*5th-Level Transmutation*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (a crystal rod worth at least 5000 gp, which the spell consumes)  
**Duration:** Instantaneous

Holding the rod used in the casting of the spell, you touch a Large or smaller chair that is unoccupied. The rod disappears, and the chair is transformed into a [Spelljamming Helm](Spelljamming Helm).

***Spell Lists.*** [Artificer](Artificer), [Wizard](Wizard)