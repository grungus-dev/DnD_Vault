Source: Unearthed Arcana 78 - Draconic Options

*4th-level enchantment*

**Casting Time:** 1 action  
**Range:** 120 feet  
**Components:** V  
**Duration:** Instantaneous

You unleash a shimmering lance of psychic power from your forehead at a creature that you can see within range. Alternatively, you can utter the creature's name. If the named target is within range, it gains no benefit from cover or invisibility as the lance homes in on it. If the named target isn't within range, the lance dissipates, and the spell slot is not expended.

The target must succeed on an Intelligence saving throw or take 10d6 psychic damage and be incapacitated until the start of your next turn.

***At Higher Levels.*** When you cast this spell using a spell slot of 5th level or higher, the damage increases by 1d6 for each slot level above 4th.

***Spell Lists.*** [Bard](Bard), [Sorcerer](Sorcerer), [Warlock](Warlock), [Wizard](Wizard)