Source: Unearthed Arcana 36 - Starter Spells

*1st-level enchantment*

**Casting Time:** 1 bonus action  
**Range:** 10 feet  
**Components:** V  
**Duration:** Instantaneous

Each sleeping creature you choose within range awakens, and then each prone creature within range can stand up without expending any movement.

***Spell Lists.*** [Bard](Bard), [Ranger](Ranger), [Sorcerer](Sorcerer), [Wizard](Wizard)