Source: Acquisitions Inc.

*1st-level evocation*

**Casting Time:** 1 action  
**Range:** 120 feet  
**Components:** V, S, M (1 gold coin, which is consumed as tax for using the spell)  
**Duration:** Instantaneous

You create three twisting, whistling, hypoallergenic, gluten-free darts of magical force. Each dart can target a creature of your choice that you can see within range. Make a ranged spell attack for each missile. On a hit, the missile does 2d4 force damage.

If the attack roll scores a critical, the missile does 5d4 force damage instead of the 4d4 force that you would normally get on a critical. If any of the attack roll is a natural one, all missiles turn around and hit the caster for 1 force damage per missile.

***At Higher Levels.*** When you cast this spell using a spell slot of 2nd level or higher, the spell creates one more dart for each slot level above 1st. This also increases the tax by 1 gp per spell slot over 1st.

***Spell Lists.*** [Wizard](Wizard)