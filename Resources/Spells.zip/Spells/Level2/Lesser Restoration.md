Source: Player's Handbook

*2nd-level abjuration*

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S  
**Duration:** Instantaneous

You touch a creature and can end either one disease or one condition afflicting it. The condition can be blinded, deafened, paralyzed, or poisoned.

***Spell Lists.*** [Artificer](Artificer), [Bard](Bard), [Cleric](Cleric), [Druid](Druid), [Paladin](Paladin), [Ranger](Ranger)